# Line sizing

To create line sizing tool

## Instructions

1. Install:

```
pip install Line_sizing
```

